﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using FYP.Models;
using System.Dynamic;
using Microsoft.AspNetCore.Authorization;
using System.Security.Claims;
using Microsoft.AspNetCore.Mvc.Rendering;

namespace FYP.Controllers
{
    public class XiohooController : Controller
    {
        public IActionResult Index()
        {
            
            return View();
        }

        public IActionResult Trainer()
        {

            List<Trainer> model = DBUtl.GetList<Trainer>("SELECT * FROM Trainer");
            return View(model);
        }

        [Authorize]
        public IActionResult TrainerEdit(int Id)
        {
            
            // Implement your code here(Done)
            var trainerEdit = DBUtl.GetList("SELECT TrainerID, Email FROM Trainer ORDER BY Course");
            ViewData["trainerEdit"] = new SelectList(trainerEdit, "TrainerID", "Email");

            string userid = HttpContext.User.FindFirst(ClaimTypes.NameIdentifier).Value;
            List<Trainer> lstTrainer = DBUtl.GetList<Trainer>("SELECT * FROM Trainer WHERE TrainerID = {0} and Email='{1}'",
                Id, userid);

            Trainer model = null;
            if (lstTrainer.Count > 0)
            {
                
                return View("TrainerEdit",model);
            }
            else
            {
                TempData["Msg"] = $"Booking {Id} not found!";
                return View("Index");
            }


        }


        [HttpPost]
        [Authorize]
        public IActionResult TrainerEdit(Trainer train)
        {
            // Implement your code here(Done)
            if (ModelState.IsValid)
            {
                
                if (DBUtl.ExecSQL(@"UPDATE Trainer
                    SET Email='{1}',  Password='{2}', Course='{3}', Status={1} WHERE TrainerID = {0}",  

                    train.Email,train.Password,train.Course,train.Status,train.TrainerID) ==1)
                    TempData["Msg"] = $"Trainer {train.TrainerID} updated.";
                else
                    TempData["Msg"] = DBUtl.DB_Message;
                return RedirectToAction("Index");
            }
            else
            {
                TempData["Msg"] = "Invalid information entered!";
                return RedirectToAction("Index");
            }

        }




        public IActionResult Attendance()
           
        {
            return View();
        }

        public IActionResult Admin()

        {
            return View();
        }

        public IActionResult Course()

        {
            return View();
        }

        public IActionResult Survey()

        {
            return View();
        }


    }
}
